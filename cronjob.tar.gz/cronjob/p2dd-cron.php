<?php
require_once __DIR__ . '/vendor/autoload.php';

use Symfony\Component\Mailer\Exception\TransportExceptionInterface;
use Symfony\Component\Mailer\Transport;
use Symfony\Component\Mailer\Mailer;
use Symfony\Component\Mime\Email;

$pdo = require 'connect.php';

$date = date("d-m-Y");
$time = date("H:i:s");
$dt = $date." ".$time;
echo "[".$dt."] RUN \n";
$client = new \GuzzleHttp\Client();
$response = $client->request('GET', 'http://localhost/p2dd/api/TemplateData/keluaran/1620.json');
$body = json_decode($response->getBody());
$items = $body->data->items;
// printf($date);
// print_r($items);
foreach ($items as $k => $v) {
    if ($v->tgl_akhir == $date) {
        echo "[".$dt."] ============================================".PHP_EOL;
        echo "[".$dt."] Update status pelaporan menjadi di proses.\n";
        $affectedRows = update($pdo, $v->id);
        // $affectedRows = 1;
        echo "[".$dt."] Number of row affected " . $affectedRows ."\n";
        echo "[".$dt."] Update selesai.\n";
        $data = select($pdo, $v->id);
        foreach ($data as $key => $value) {
            echo "[".$dt."] ============================================".PHP_EOL;
            echo "[".$dt."] Mulai mengirim email ke ".$value["email"]."\n";
            $to = $value["email"];
            $subject = "Kuisoner Telah Terkirim";
            $body = "Kuesioner telah terkirim dengan hasil yang sudah terisikan sebagai berikut";
            sendEmail($to, $subject, $body);
            echo "[".$dt."] Email terkirim ke ".$to."\n";
        }
    }
}
echo "[".$dt."] STOP\n";

function update($pdo, $id) {
    $sql = "UPDATE c_pelaporan SET status='proses' WHERE periode_id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $id);
    $stmt->execute();
    return $stmt->rowCount();
}

function select($pdo, $id) {
    $sql = "SELECT * FROM c_pelaporan WHERE periode_id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $id);
    $stmt->execute();
    $data = [];
    while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
        $data[] = [
            'id' => $row['id'],
            'instansi_id' => $row['instansi_id'],
            'email' => $row['email']
        ];
    }
    return $data;
}

function sendEmail($to, $subject, $body)
{
    $transport = Transport::fromDsn('smtp://p2dd-dev:b3hvaTR3bDhvc2Ew@mail.smtp2go.com:25');
    $mailer = new Mailer($transport);
    
    $email = (new Email())
        ->from('postmaster@p2dd.go.id')
        ->to($to)
        //->cc('cc@example.com')
        //->bcc('bcc@example.com')
        //->replyTo('fabien@example.com')
        //->priority(Email::PRIORITY_HIGH)
        ->subject($subject)
        // ->text('Sending emails is fun again!')
        ->html($body);
    
    try {
        $mailer->send($email);
    } catch (TransportExceptionInterface $e) {
        // some error prevented the email sending; display an
        // error message or try to resend the message
        print_r($e->getDebug());
    }
}
