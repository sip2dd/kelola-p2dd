<?php

$host= 'localhost';
$db = 'sip2dd';
$user = 'hakase';
$password = 'hakasepasspgsql';